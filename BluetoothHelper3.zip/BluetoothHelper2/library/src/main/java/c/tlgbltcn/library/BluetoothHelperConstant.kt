package c.tlgbltcn.library

/**
 * Created by tolga bolatcan on 24.01.2019
 */
object BluetoothHelperConstant {

    const val ACCESS_FINE_LOCATION = "Manifest.permission.ACCESS_FINE_LOCATION"
    const val ACCESS_COARSE_LOCATION = "Manifest.permission.ACCESS_COARSE_LOCATION"
    const val REQ_CODE = 1001
}