package c.tlgbltcn.bluetoothhelper

import android.os.Bundle
import android.os.PersistableBundle
import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.jjoe64.graphview.GraphView
import com.jjoe64.graphview.series.DataPoint
import com.jjoe64.graphview.series.PointsGraphSeries

class MapActivity :AppCompatActivity() {
    //add PointsGraphSeries of DataPoint type
    var xySeries: PointsGraphSeries<DataPoint>? = null
    private var btnAddPt: Button? = null
    private var mX: TextView? = null
    private var mY: TextView? = null
    var mScatterPlot: GraphView? = null
    var x:Double=0.0
    var y:Double=0.0
    private var xyValueArray: ArrayList<XYValue>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.map)
        //GETTING X & Y
        x = intent.getDoubleExtra("x",0.0)
        y = intent.getDoubleExtra("y",0.0)

        //declare variables in oncreate
        btnAddPt = findViewById<View>(R.id.btnAddPt) as Button
        mX = findViewById<View>(R.id.numX) as TextView
        mY = findViewById<View>(R.id.numY) as TextView
        mScatterPlot = findViewById<View>(R.id.scatterPlot) as GraphView
        xyValueArray = ArrayList()
        init()

    }
    private fun init() {
        //declare the xySeries Object
        xySeries = PointsGraphSeries()
        btnAddPt!!.setOnClickListener {
            if (x != 0.0 && y != 0.0) {

                mX?.text=x.toString()
                mY?.text=y.toString()
                Log.d(
                    TAG,
                    "onClick: Adding a new point. (x,y): ($x,$y)"
                )
                xyValueArray!!.add(XYValue(0.0, 0.0))
                xyValueArray!!.add(XYValue(10.0, 0.0))
                xyValueArray!!.add(XYValue(5.0, 10.0))
                xyValueArray!!.add(XYValue(x, y))


                init()
            } else {
                toastMessage("You must fill out both fields!")
            }
        }

        //little bit of exception handling for if there is no data.
        if (xyValueArray!!.size != 0) {
            createScatterPlot()
        } else {
            Log.d(TAG, "onCreate: No data to plot.")
        }
    }

    private fun createScatterPlot() {
        Log.d(TAG, "createScatterPlot: Creating scatter plot.")

        //sort the array of xy values
        xyValueArray = sortArray(xyValueArray)

        //add the data to the series
        for (i in xyValueArray!!.indices) {
            try {
                val x = xyValueArray!![i].x
                val y = xyValueArray!![i].y
                xySeries!!.appendData(DataPoint(x, y), true, 1000)
            } catch (e: IllegalArgumentException) {
                Log.e(TAG, "createScatterPlot: IllegalArgumentException: " + e.message)
            }
        }

        //set some properties
        xySeries!!.shape = PointsGraphSeries.Shape.POINT
        xySeries!!.color = Color.BLUE
        xySeries!!.size = 20f

        //set Scrollable and Scaleable
        mScatterPlot!!.viewport.isScalable = true
        mScatterPlot!!.viewport.setScalableY(true)
        mScatterPlot!!.viewport.isScrollable = true
        mScatterPlot!!.viewport.setScrollableY(true)

        //set manual x bounds
        mScatterPlot!!.viewport.isYAxisBoundsManual = true
        mScatterPlot!!.viewport.setMaxY(10.0)
        mScatterPlot!!.viewport.setMinY(0.0)

        //set manual y bounds
        mScatterPlot!!.viewport.isXAxisBoundsManual = true
        mScatterPlot!!.viewport.setMaxX(10.0)
        mScatterPlot!!.viewport.setMinX(0.0)
        mScatterPlot!!.addSeries(xySeries)
    }

    /**
     * Sorts an ArrayList<XYValue> with respect to the x values.
     * @param array
     * @return
    </XYValue> */
    private fun sortArray(array: ArrayList<XYValue>?): ArrayList<XYValue>? {
        /*
        //Sorts the xyValues in Ascending order to prepare them for the PointsGraphSeries<DataSet>
         */
        val factor = Math.round(Math.pow(array!!.size.toDouble(), 2.0)).toString().toInt()
        var m = array.size - 1
        var count = 0
        Log.d(TAG, "sortArray: Sorting the XYArray.")
        while (true) {
            m--
            if (m <= 0) {
                m = array.size - 1
            }
            Log.d(TAG, "sortArray: m = $m")
            try {
                //print out the y entrys so we know what the order looks like
                //Log.d(TAG, "sortArray: Order:");
                //for(int n = 0;n < array.size();n++){
                //Log.d(TAG, "sortArray: " + array.get(n).getY());
                //}
                val tempY = array[m - 1].y
                val tempX = array[m - 1].x
                if (tempX > array[m].x) {
                    array[m - 1].y = array[m].y
                    array[m].y = tempY
                    array[m - 1].x = array[m].x
                    array[m].x = tempX
                } else if (tempX == array[m].x) {
                    count++
                    Log.d(TAG, "sortArray: count = $count")
                } else if (array[m].x > array[m - 1].x) {
                    count++
                    Log.d(TAG, "sortArray: count = $count")
                }
                //break when factorial is done
                if (count == factor) {
                    break
                }
            } catch (e: ArrayIndexOutOfBoundsException) {
                Log.e(
                    TAG,
                    "sortArray: ArrayIndexOutOfBoundsException. Need more than 1 data point to create Plot." +
                            e.message
                )
                break
            }
        }
        return array
    }

    /**
     * customizable toast
     * @param message
     */
    private fun toastMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val TAG = "MapActivity"
    }
}