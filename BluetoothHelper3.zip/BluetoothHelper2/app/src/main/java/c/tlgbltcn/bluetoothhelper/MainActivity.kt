package c.tlgbltcn.bluetoothhelper

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import c.tlgbltcn.bluetoothhelper.databinding.ActivityMainBinding
import c.tlgbltcn.library.BluetoothHelper
import c.tlgbltcn.library.BluetoothHelperListener
import kotlin.math.pow

class MainActivity : AppCompatActivity(), BluetoothHelperListener {


    private lateinit var bluetoothHelper: BluetoothHelper
    private lateinit var binding: ActivityMainBinding
    private lateinit var handler: Handler
    private lateinit var refreshRunnable: Runnable
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private var itemList = ArrayList<BluetoothDeviceModel>()
     var d1: Double = 0.0
     var d2: Double = 0.0
     var d3: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        bluetoothHelper = BluetoothHelper(this@MainActivity, this@MainActivity)
                .setPermissionRequired(true)
                .create()

        if (bluetoothHelper.isBluetoothEnabled()) binding.enableDisable.text = "Bluetooth State Off"
        else binding.enableDisable.text = "Bluetooth State On"

        if (bluetoothHelper.isBluetoothScanning()) binding.startStop.text = "Stop discovery"
        else binding.startStop.text = "Start discovery"

        binding.enableDisable.setOnClickListener {
            if (bluetoothHelper.isBluetoothEnabled()) {

                bluetoothHelper.disableBluetooth()

            } else {
                bluetoothHelper.enableBluetooth()
            }
        }

        binding.startStop.setOnClickListener {
            if (bluetoothHelper.isBluetoothScanning()) {
                bluetoothHelper.stopDiscovery()

            } else {
                bluetoothHelper.startDiscovery()
            }
        }
        binding.location.setOnClickListener{
            Toast.makeText(this,"Wait for the distance to load",Toast.LENGTH_SHORT).show()}

        viewAdapter = BluetoothListAdapter(itemList)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = viewAdapter
        }
        handler = Handler()
        refreshRunnable=  object : Runnable {
            override fun run() {
                // Perform click on refresh button
                binding.startStop.performClick()

                // Schedule next click after 1 second
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(refreshRunnable)

    }


    override fun onStartDiscovery() {
        binding.startStop.text = "Stop discovery"
        d1=0.0
        d2=0.0
        d3=0.0
        }

    override fun onFinishDiscovery() {
        binding.startStop.text = "Start discovery"
        itemList.clear()
    }

    override fun onEnabledBluetooth() {
        binding.enableDisable.text = "Bluetooth State Off"
    }

    override fun onDisabledBluetooh() {
        binding.enableDisable.text = "Bluetooth State On"

    }
    // Calculate the distance in meters from the RSSI value
    private fun calculateDistance(rssi: Int): Double {
        val txPower = -59 // The reference RSSI at 1 meter distance
        val ratio = rssi.toDouble() / txPower.toDouble()

        if (ratio < 1.0) {
            return Math.pow(ratio, 10.0)
        } else {
            val distance = (0.89976 * Math.pow(ratio, 7.7095) + 0.111) * ratio.toDouble()
            return distance
        }
    }

    @SuppressLint("NotifyDataSetChanged","MissingPermission")
    override fun getBluetoothDeviceList(device: BluetoothDevice?,rssi:String) {
        val int_rssi =rssi.toDouble()
        val distance= calculateDistance(rssi.toInt())

        if(distance<10) {
            if (device?.name == "DESKTOP-2NA1HJE" || device?.name == "HC-05"||device?.name == "Omar") {

                itemList.add(
                    BluetoothDeviceModel(
                        "Device Name :" + device?.name,
                        "Device Mac : " + device?.address,
                        "RSSI : $rssi ",
                        distance.toString()
                    )
                )
                viewAdapter.notifyDataSetChanged()
            }
//                d3=distance
//
//            } else if (device?.name == "HC-05") {
//                itemList.add(BluetoothDeviceModel( "Device Name :"+device?.name,"Device Mac : "+ device?.address,"Distance : $distance "))
//                viewAdapter.notifyDataSetChanged()
//                d1=distance
//
//            } else if (device?.name == "OPPO Reno2 F") {
//                itemList.add(BluetoothDeviceModel("Device Name :"+device?.name,"Device Mac : "+ device?.address,"Distance : $distance "))
//                viewAdapter.notifyDataSetChanged()
//                d2=distance
//            }
            //   }
            d1 = 5.83
            d3 = 5.38
            d2 = 8.60
            val x1 = 0f
            val y1 = 0f
            val x3 = 5f
            val y3 = 10f
            val x2 = 10f
            val y2 = 0f
            val delta = 4 * ((x1 - x2) * (y1 - y3) - (x1 - x3) * (y1 - y2))
            val A: Double =
                d2.pow(2.0) - d1.pow(2.0) - x2.toDouble().pow(2.0) + x1.toDouble()
                    .pow(2.0) - y2.toDouble().pow(2.0) + y1.toDouble().pow(2.0)
            val B: Double =
                d3.pow(2.0) - d1.pow(2.0) - x3.toDouble().pow(2.0) + x1.toDouble()
                    .pow(2.0) - y3.toDouble().pow(2.0) + y1.toDouble().pow(2.0)

            val x = 1 / delta * (2 * A * (y1 - y3) - 2 * B * (y1 - y2))

            val y = 1 / delta * (2 * B * (x1 - x2) - 2 * A * (x1 - x3))

//Navigate to maps activity and pass x&y
            binding.location.setOnClickListener {
                val intent = Intent(this@MainActivity, MapActivity::class.java)
                intent.putExtra("x", x)
                intent.putExtra("y", y)
                startActivity(intent)
            }

        }
    }

    override fun onDestroy() {
        super.onDestroy()

        // Stop automatic refresh
        handler.removeCallbacks(refreshRunnable)
    }


override fun onResume() {
        super.onResume()
        bluetoothHelper.registerBluetoothStateChanged()
    }


    override fun onStop() {
        super.onStop()
        bluetoothHelper.unregisterBluetoothStateChanged()
    }
}

