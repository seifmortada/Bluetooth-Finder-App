package c.tlgbltcn.bluetoothhelper

class XYValue(var x: Double, var y: Double)